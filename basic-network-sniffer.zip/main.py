try:
    from scapy.all import sniff, IP, TCP, UDP, ICMP, Raw
except ModuleNotFoundError:
    print("ERROR: Scapy is not installed.")
    print("Install it using: pip install scapy")
    exit()


def process_packet(packet):
    print("\n================ PACKET CAPTURED ================")

    # IP Layer
    if packet.haslayer(IP):
        ip = packet[IP]
        print(f"Source IP       : {ip.src}")
        print(f"Destination IP  : {ip.dst}")

        proto_map = {1: "ICMP", 6: "TCP", 17: "UDP"}
        print(f"Protocol        : {proto_map.get(ip.proto, ip.proto)}")

    # TCP Layer
    if packet.haslayer(TCP):
        tcp = packet[TCP]
        print("Protocol Type   : TCP")
        print(f"Source Port     : {tcp.sport}")
        print(f"Destination Port: {tcp.dport}")

    # UDP Layer
    if packet.haslayer(UDP):
        udp = packet[UDP]
        print("Protocol Type   : UDP")
        print(f"Source Port     : {udp.sport}")
        print(f"Destination Port: {udp.dport}")

    # ICMP Layer
    if packet.haslayer(ICMP):
        print("Protocol Type   : ICMP")

    # Payload Data
    if packet.haslayer(Raw):
        try:
            payload = packet[Raw].load
            print(f"Payload (first 50 bytes): {payload[:50]}")
        except:
            print("Payload: Unable to decode")


def main():
    print("=======================================")
    print("   SIMPLE NETWORK PACKET SNIFFER")
    print("   Press CTRL + C to stop")
    print("=======================================\n")

    # Capture packets continuously
    sniff(prn=process_packet, store=False)


if __name__ == "__main__":
    main()